console.log('Hello World!');
function paxtachi() {
    let x = document.getElementById('paxta').value ,
        y = document.getElementById('skidka').value ,
        z = document.getElementById('narx').value ,
        b = document.getElementById('p')
        q = x *   y / 100 ,
        a =  ((x-q) * z );
        console.log (`Sizning tergan paxtangiz ${x}. Shundan ayiriladigan skidka miqdori ${q} kg. Qolgan paxta ${x-q} kg va jami summa ${a} so'm. `);
        b.innerHTML = (`Sizning tergan paxtangiz ${x}. Shundan ayiriladigan skidka miqdori ${q} kg. Qolgan paxta ${x-q} kg va jami summa ${a} so'm.`);

}
paxtachi()
 